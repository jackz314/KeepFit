package com.jackz314.keepfit;

public class GlobalConstants {
    public static final int RC_SIGN_IN = 100;
    public static final int RC_REAUTH_DELETE = 200;

    public static final String PRIVACY_POLICY_URL = "https://www.usc.edu/pages/usc-privacy-notice/";
    public static final String TOS_URL = "https://www.usc.edu/pages/usc-privacy-notice/";
}
